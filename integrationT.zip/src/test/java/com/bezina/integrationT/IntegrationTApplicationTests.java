package com.bezina.integrationT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegrationTApplicationTests {

	@Test
	void contextLoads() {
	}

}
